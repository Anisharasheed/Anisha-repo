class SpotifyCredentials {
  static const String clientId = "05e76370c5654a1eaa8db59ce344377f";  // 🔥 Replace with actual Client ID
  static const String clientSecret = "66b248b7cdff4cc9a42d6fdd34cd63bb";  // 🔥 Replace with actual Client Secret
}
